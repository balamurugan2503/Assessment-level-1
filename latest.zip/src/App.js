import './App.css';
import CollapsibleExample from './Components/Home';
import Login from './Components/Login';


function App() {
 
  return (
    <div className="App">
 {/* <Login /> */}
 <CollapsibleExample />
    </div>
  );
}

export default App;
