import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import '../Components/home.css'

function CollapsibleExample() {
  return (
    // <div className='page-wrapper'>
    //     <div className='left-content'></div>
    <Navbar collapseOnSelect expand="sm" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand >Countries</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          
          <Nav className="ms-auto">
            <Nav.Link href="#deets">All</Nav.Link>
            <Nav.Link href="#deets">Asia</Nav.Link>
            <Nav.Link href="#deets">Europe</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default CollapsibleExample;