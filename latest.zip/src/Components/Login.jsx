import React from 'react'
import { Button, Form } from 'react-bootstrap'
import '../Components/login.css'

export default function Login() {
  return (
  <>
  <div >
    <div className='page-wrapper'>
        <div className='left-content'>
            <div className='title-content'>
                <h3 >Sign In</h3>
                <div className='link-btn'>
                    <p>New user?</p>
                    <a href="#">Create an account</a>
                </div>
            </div>
            <Form className='form-input'>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Control type="email" placeholder="Username or email" />
                </Form.Group>
                <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                    <Form.Control type="email" placeholder="Password" />
                </Form.Group>
            </Form>
            <Form.Check
            inline
            label="Keep me signed in"
            name="group1"
            type="checkbox"
            id="2"
          />
           <Button className="sigin-btn">Sign In</Button>
           <div className='sigup'>
            <div className='line'></div>
            <p>Or Sign In With</p>
            <div className='line'></div>
           </div>
           <div className='foot-icon'>
                <Button className='icon'>
                    <img/>
                </Button>
                <Button className='icon'>
                    <img/>
                </Button>
                <Button className='icon'>
                    <img/>
                </Button>
                <Button className='icon'>
                    <img/>
                </Button>
            </div>
        </div>
    </div>
  </div>
  </>
  )
}
